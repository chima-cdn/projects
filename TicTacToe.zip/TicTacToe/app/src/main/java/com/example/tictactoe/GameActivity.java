package com.example.tictactoe;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.Html;
import android.util.Log;
import android.view.OrientationEventListener;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.firebase.FirebaseError;
import com.google.firebase.Timestamp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.Nullable;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class GameActivity extends AppCompatActivity implements  View.OnClickListener{

    private Button[][] buttons = new Button[10][10];

    private boolean player1Turn = true;

    private int roundCount;

    private int player1Points;
    private int player2Points;

    private TextView textViewPlayer1;
    private TextView textViewPlayer2;

    boolean player1turn_from_network=true;

    FirebaseFirestore db;

    int row_number_for_X;
    int col_number_for_X;

    int row_number_for_O;
    int col_number_for_O;

    String finalarray[][] = new String[10][10];

    int seperate_digit_op_for_X = 0;
    int seperate_digit_op_for_O = 0;

    String concatenated_string_for_X = "";
    String concatenated_string_for_O = "";

    int mycount_for_X = 0;
    int mycount_for_O = 0;

    String TAG="Document Snapshot";

    boolean isGameStateFinished = true;

    ArrayList<String> myList,blank_list;

    String got_array[][] = new String[10][10];

    boolean you_clicked =false;
    boolean is_game_reset = false;
    int player_1_count = 0;
    int player_2_count = 0;
    String androidID="";

    ArrayList<String> gotList;

    String received_android_id="";

    String player1count_from_network="";
    String player2count_from_network="";

    String player1points_from_network="";
    String player2points_from_network="";

    boolean isPortrait = true;

    Bundle MySavedInstanceState = null;

    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);//added scrollview and one parent linear layout to scroll
        this.MySavedInstanceState = savedInstanceState;



sp=GameActivity.this.getApplicationContext().getSharedPreferences("tictactoe", 0);

        androidID = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);//get An android id of device-for that add permission in manifest read privileged phone state

        db = FirebaseFirestore.getInstance();

        textViewPlayer1 = findViewById(R.id.text_view_p1);//player1 points
        textViewPlayer2 = findViewById(R.id.text_view_p2);//player2 points



        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                String buttonID = "button_" + i + j;
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                buttons[i][j] = findViewById(resID);
                buttons[i][j].setOnClickListener((View.OnClickListener) this);
            }
        }

        Button buttonReset = findViewById(R.id.button_reset);
        buttonReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                resetGame();
            }
        });

      // takeSnapshot();

        final DocumentReference docRef1 = db.collection("games").document("MyDoc1");//Tell firestore in which database which collection which document you want to read
        docRef1.addSnapshotListener(new EventListener<DocumentSnapshot>() {//Take a snapsot of database-automatically called when database entries are updated
            @Override
            public void onEvent(@Nullable DocumentSnapshot snapshot,
                                @Nullable FirebaseFirestoreException e) {
                if (e != null) {
                    Log.w(TAG, "Listen failed.", e);
                    Toast.makeText(GameActivity.this,"Listen failed."+snapshot.getData(),Toast.LENGTH_LONG).show();

                    return;
                }

                if (snapshot != null && snapshot.exists()) {//if snapshot  is not null
                    Log.d(TAG, "Current data: " + snapshot.getData());
                   // Toast.makeText(GameActivity.this,"Current data:"+snapshot.getData(),Toast.LENGTH_LONG).show();

                     gotList = (ArrayList<String>) snapshot.get("field");

                   /* //Set the values
                    Set<String> set = new HashSet<String>();
                    set.addAll(myList);
                    sp.pu("key", set);
                    scoreEditor.commit();*/



                    player1turn_from_network = Boolean.parseBoolean(snapshot.get("player1turn").toString());//take if player1 turn is true or false

                    received_android_id = snapshot.get("played_device_id").toString();//take who is played latest
                    player1count_from_network = snapshot.get("player_1_count").toString();//player1 count
                    player2count_from_network = snapshot.get("player_2_count").toString();//player2 count

                   /* textViewPlayer1.setText("Player 1 : "+player1count_from_network);
                    textViewPlayer2.setText("Player 2 : "+player2count_from_network);*/

                    player1points_from_network = snapshot.get("player1Points").toString();//how many times player1 won
                    player2points_from_network = snapshot.get("player2Points").toString();//how many times player2 won


                    //  Toast.makeText(GameActivity.this,"player1points_from_network = "+player1points_from_network+"player2points_points = "+player2points_from_network,Toast.LENGTH_LONG).show();

                    textViewPlayer1.setText("Player 1 : "+player1points_from_network);//settext latest point of player1
                    textViewPlayer2.setText("Player 2 : "+player2points_from_network);//settext latest point of player2

                 /*   if (checkForWin()) {
                        if (player1Turn) {
                            textViewPlayer1.setText("Player 1 : "+player1points_from_network);
                            textViewPlayer2.setText("Player 2 : "+player2points_from_network);

                            player1Wins();
                        } else {
                            textViewPlayer1.setText("Player 1 : "+player1points_from_network);
                            textViewPlayer2.setText("Player 2 : "+player2points_from_network);
                            player2Wins();
                        }
                    }
                    else if (roundCount == 100) {
                        draw();
                    } else {
                        player1Turn = !player1Turn;
                    }*/


                //    Toast.makeText(GameActivity.this,"Player1 turn from network"+player1turn_from_network+" & received android id="+received_android_id,Toast.LENGTH_LONG).show();

                    for(int i=0;i<gotList.size();i++)
                    {
                        if (gotList.get(i) != null) {
                            buttons[i/10][i%10].setText(gotList.get(i).toString());//Display all entries on buttons

                        }
                    }
                } else {
                    Log.d(TAG, "Current data: null");
                }
            }
        });



        DocumentReference docRef = db.collection("games").document("MyDoc1");
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {//on activity created take previos game state if game is not finishd yet
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        isGameStateFinished = Boolean.parseBoolean(document.get("finished").toString());//if game finished or not


                        if (isGameStateFinished == false) {//if not finished,get list
                            try {

                              //  Toast.makeText(GameActivity.this, "Game has not WON yet.Fetching its state NOW...", Toast.LENGTH_LONG).show();

                            DocumentReference docRef = db.collection("games").document("MyDoc1");
                            docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                    if (task.isSuccessful()) {
                                        DocumentSnapshot document = task.getResult();
                                        if (document.exists()) {

                                            ArrayList<String> gotList = (ArrayList<String>) document.get("field");//get Arraylist to gotList


                                            for(int i=0;i<gotList.size();i++)
                                            {
                                                if (gotList.get(i) != null) {
                                                    buttons[i/10][i%10].setText(gotList.get(i).toString());//update buttons state accordingly

                                                }
                                            }



                                            Log.d(TAG, "DocumentSnapshot data: " + document.get("finished"));
                                        } else {
                                            Log.d(TAG, "No such document");
                                        }
                                    } else {
                                        Log.d(TAG, "get failed with ", task.getException());
                                    }
                                }
                            });
                        }catch(Exception ex)
                        {
                           // Toast.makeText(GameActivity.this,"Exception reading"+ex.toString(),Toast.LENGTH_LONG).show();
                        }
                    }
                        else if(isGameStateFinished==true)
                        {
                           // Toast.makeText(GameActivity.this,"Game is not started yet or last winner is already declared",Toast.LENGTH_LONG).show();

                           // *******

                           /* docRef
                                    .update("played_device_id", androidID)
                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            Log.d(TAG, "DocumentSnapshot successfully UPDATED you_clicked FALSE!");
                                        }
                                    })
                                    .addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Log.w(TAG, "Error updating document", e);
                                        }
                                    });*/

                        }


                    } else {
                        Log.d(TAG, "No such document");
                    }
                } else {
                    Log.d(TAG, "get failed with ", task.getException());
                }
            }
        });

        //takeSnapshot();

    }



    @Override
    public void onClick(View v) {
        try {


            if (!((Button) v).getText().toString().equals("")) {
                return;
            }


            DocumentReference docRef = db.collection("games").document("MyDoc1");

             if (player1turn_from_network==true && !(received_android_id.equals(androidID))) {// if player1turn is true and my android id and played android id is not same
               /* Toast.makeText(GameActivity.this,"Now it's player 1 turn please wait dear PLAYER 2...!",Toast.LENGTH_LONG).show();*/

                player_1_count++;

                //((Button) v).setText("X");
                ((Button) v).setText(Html.fromHtml("X"));


                //Toast.makeText(GameActivity.this,((Button)v).toString(),Toast.LENGTH_LONG).show();

                String test = ((Button) v).toString();

                int resID = getResources().getIdentifier(test, "id", getPackageName());

                String mybuttonpos[] = test.split("_");// jsjskfns_03}//Button id split by underscore and take right side part.for e.g.in this jsjskfns_03},  output is 03}


                //Toast.makeText(GameActivity.this,"MyButtons after split"+mybuttonpos[1],Toast.LENGTH_LONG).show();


                char myarr[] = mybuttonpos[1].toCharArray();// 03}-take only 0 and 3,not curly brace

                //Toast.makeText(GameActivity.this,"myarr[0]="+myarr[0]+"myarr[1]="+myarr[1],Toast.LENGTH_LONG).show();

                String mystring = myarr[0] + "" + myarr[1];//03

                row_number_for_X = Integer.parseInt(String.valueOf(myarr[0]));//0 is my row
                col_number_for_X = Integer.parseInt(String.valueOf(myarr[1]));//3 is my column

           //     Toast.makeText(GameActivity.this,"Player1 clicked on "+row_number_for_X+"Column no"+col_number_for_X,Toast.LENGTH_LONG).show();
               // Toast.makeText(GameActivity.this, "BLOCK1 ROW_NUMBER =" + row_number_for_X + " and COLUMN NUMBER=" + col_number_for_X + " " + concatenated_string_for_X, Toast.LENGTH_LONG).show();

                finalarray[row_number_for_X][col_number_for_X] = "X";//update location in two dimensional finalarray

                int num = Integer.parseInt(mystring); // int number

                myList = new ArrayList<>();
                for (int i = 0; i < 10; i++) {
                    for (int j = 0; j < 10; j++) {
                        myList.add(finalarray[i][j]);//update arraylist to save in database
                    }
                }

                Map<String, Object> docData = new HashMap<>();
                docData.put("created_date", new Timestamp(new Date()));
                docData.put("field",myList);
                docData.put("finished", false);
                docData.put("winner_id", 0);
                docData.put("you_clicked", true);
                docData.put("player_1_count",player_1_count);
                docData.put("player_2_count",player_2_count);
                docData.put("player1turn", false);
                docData.put("player1Points",player1points_from_network);
                 docData.put("player2Points",player2points_from_network);//create and put values of all fields

               /* if(player1turn_from_network==false) {
                    docData.put("player1turn", true);
                }
                else
                {
                    docData.put("player1turn", false);
                }*/
                docData.put("played_device_id",androidID);

                docRef
                        .update("you_clicked", true)//update you clicked
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Log.d(TAG, "DocumentSnapshot successfully UPDATED you_clicked FALSE!");
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.w(TAG, "Error updating document", e);
                            }
                        });

                 docRef
                         .update("field", myList)//update arraylist-here both put and update is important ,otherwise it will not be updated
                         .addOnSuccessListener(new OnSuccessListener<Void>() {
                             @Override
                             public void onSuccess(Void aVoid) {
                                 Log.d(TAG, "DocumentSnapshot successfully UPDATED you_clicked FALSE!");
                             }
                         })
                         .addOnFailureListener(new OnFailureListener() {
                             @Override
                             public void onFailure(@NonNull Exception e) {
                                 Log.w(TAG, "Error updating document", e);
                             }
                         });

                docRef
                        .update("played_device_id", androidID)//update who played?device id
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Log.d(TAG, "DocumentSnapshot successfully UPDATED you_clicked FALSE!");
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.w(TAG, "Error updating document", e);
                            }
                        });





                try{





                docRef
                            .update("player1turn", false)//make player1 turn to false-he played now
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Log.d(TAG, "DocumentSnapshot successfully UPDATED you_clicked FALSE!");
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.w(TAG, "Error updating document", e);
                                }
                            });

                    docRef
                            .update("played_device_id", androidID)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Log.d(TAG, "DocumentSnapshot successfully UPDATED you_clicked FALSE!");
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.w(TAG, "Error updating document", e);
                                }
                            });

                    docRef
                            .update("player_1_count", player_1_count)//update player1 count
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Log.d(TAG, "DocumentSnapshot successfully UPDATED you_clicked FALSE!");
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.w(TAG, "Error updating document", e);
                                }
                            });


                    refresh();

                } catch (Exception ex) {
                    // Toast.makeText(GameActivity.this,"Exception = "+ex.toString(),Toast.LENGTH_LONG).show();
                    System.out.println("My Exception =" + ex.toString());
                    ex.printStackTrace();
                }
            } else if(player1turn_from_network==false && !(received_android_id.equals(androidID))) {//reverse of if block
              //  Toast.makeText(GameActivity.this,"Now it's player 2 turn please wait dear PLAYER 1...!",Toast.LENGTH_LONG).show();

                player_2_count++;

                // ((Button) v).setText("O");
                ((Button) v).setText(Html.fromHtml("O"));


                String test = ((Button) v).toString();

                int resID = getResources().getIdentifier(test, "id", getPackageName());

                String mybuttonpos[] = test.split("_");


                //Toast.makeText(GameActivity.this,"MyButtons after split"+mybuttonpos[1],Toast.LENGTH_LONG).show();


                char myarr[] = mybuttonpos[1].toCharArray();

                // Toast.makeText(GameActivity.this,"myarr[0]="+myarr[0]+"myarr[1]="+myarr[1],Toast.LENGTH_LONG).show();

                String mystring = myarr[0] + "" + myarr[1];

                int num = Integer.parseInt(mystring); // int number

                row_number_for_O = Integer.parseInt(String.valueOf(myarr[0]));
                col_number_for_O = Integer.parseInt(String.valueOf(myarr[1]));

                finalarray[row_number_for_O][col_number_for_O] = "O";

                //Toast.makeText(GameActivity.this, "BLOCK3 ROW_NUMBER =" + row_number_for_O + " and COLUMN NUMBER=" + col_number_for_O + " " + concatenated_string_for_O, Toast.LENGTH_LONG).show();


                docRef
                        .update("you_clicked", true)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Log.d(TAG, "DocumentSnapshot successfully UPDATED you_clicked FALSE!");
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.w(TAG, "Error updating document", e);
                            }
                        });

                try {


                    myList = new ArrayList<>();
                    for (int i = 0; i < 10; i++) {
                        for (int j = 0; j < 10; j++) {
                            myList.add(finalarray[i][j]);
                        }
                    }

                    Map<String, Object> docData = new HashMap<>();
                    docData.put("created_date", new Timestamp(new Date()));
                    docData.put("field",myList);
                    docData.put("finished", false);
                    docData.put("winner_id", 0);
                    docData.put("you_clicked", true);
                    docData.put("player_1_count",player_1_count);
                    docData.put("player_2_count",player_2_count);
                    docData.put("player1turn",true);
                    docData.put("player1Points",player1points_from_network);
                    docData.put("player2Points",player2points_from_network);
                    /*if(player1turn_from_network==false) {
                        docData.put("player1turn", true);
                    }
                    else
                    {
                        docData.put("player1turn", false);
                    }*/
                    docData.put("played_device_id",androidID);

                    db.collection("games").document("MyDoc1")
                            .set(docData)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Log.d(TAG, "DocumentSnapshot successfully written!");
                                    //  Toast.makeText(GameActivity.this,"DocumentSnapshot successfully written!",Toast.LENGTH_LONG).show();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.w(TAG, "Error writing document", e);
                                    // Toast.makeText(GameActivity.this,"Error writing document"+e.toString(),Toast.LENGTH_LONG).show();
                                }
                            });

                    docRef
                            .update("player1turn", true)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Log.d(TAG, "DocumentSnapshot successfully UPDATED you_clicked FALSE!");
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.w(TAG, "Error updating document", e);
                                }
                            });

                    docRef
                            .update("field", myList)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Log.d(TAG, "DocumentSnapshot successfully UPDATED you_clicked FALSE!");
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.w(TAG, "Error updating document", e);
                                }
                            });

                    docRef
                            .update("played_device_id", androidID)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Log.d(TAG, "DocumentSnapshot successfully UPDATED you_clicked FALSE!");
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.w(TAG, "Error updating document", e);
                                }
                            });
                    docRef
                            .update("player_2_count", player_2_count)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Log.d(TAG, "DocumentSnapshot successfully UPDATED you_clicked FALSE!");
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.w(TAG, "Error updating document", e);
                                }
                            });



               // player1turn_from_network=true
                    // refresh();


                } catch (Exception ex) {
                    // Toast.makeText(GameActivity.this,"Exception = "+ex.toString(),Toast.LENGTH_LONG).show();
                    System.out.println("My Exception =" + ex.toString());
                    ex.printStackTrace();
                }
            }


            System.out.println("______________________________");
            for (int k = 0; k < 10; k++) {

                for (int l = 0; l < 10; l++) {
                    if (finalarray[k][l] == null) {
                        continue;
                    } else {
                        System.out.println("*" + finalarray[k][l] + "* where k is=" + k + "and l is" + l);
                    }

                }
            }

            System.out.println("______________________________");





            roundCount++;

            if (checkForWin()) {
                if (player1Turn) {
                    player1Wins();
                } else {
                    player2Wins();
                }
            } else if (roundCount == 100) {
                draw();
            } else {
                player1Turn = !player1Turn;
            }
        }catch(Exception e)
        {
           // Toast.makeText(GameActivity.this,"Here exception"+e.toString(),Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        // Checks the orientation of the screen
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {//on configuration requested landscape
         //   Toast.makeText(this, "landscape", Toast.LENGTH_SHORT).show();
            DocumentReference docRef = db.collection("games").document("MyDoc1");
            docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            isGameStateFinished = Boolean.parseBoolean(document.get("finished").toString());


                            if (isGameStateFinished == false) {
                                try {

                                    //  Toast.makeText(GameActivity.this, "Game has not WON yet.Fetching its state NOW...", Toast.LENGTH_LONG).show();

                                    DocumentReference docRef = db.collection("games").document("MyDoc1");
                                    docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                        @Override
                                        public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                            if (task.isSuccessful()) {
                                                DocumentSnapshot document = task.getResult();
                                                if (document.exists()) {

                                                    ArrayList<String> gotList = (ArrayList<String>) document.get("field");//take field list from database


                                                    for(int i=0;i<gotList.size();i++)
                                                    {
                                                        if (gotList.get(i) != null) {
                                                            buttons[i/10][i%10].setText(gotList.get(i).toString());

                                                        }
                                                    }



                                                    Log.d(TAG, "DocumentSnapshot data: " + document.get("finished"));
                                                } else {
                                                    Log.d(TAG, "No such document");
                                                }
                                            } else {
                                                Log.d(TAG, "get failed with ", task.getException());
                                            }
                                        }
                                    });
                                }catch(Exception ex)
                                {
                                    // Toast.makeText(GameActivity.this,"Exception reading"+ex.toString(),Toast.LENGTH_LONG).show();
                                }
                            }
                            else if(isGameStateFinished==true)
                            {
                                // Toast.makeText(GameActivity.this,"Game is not started yet or last winner is already declared",Toast.LENGTH_LONG).show();

                                // *******


                            }


                        } else {
                            Log.d(TAG, "No such document");
                        }
                    } else {
                        Log.d(TAG, "get failed with ", task.getException());
                    }
                }
            });
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {//if requested config is portrait
         //   Toast.makeText(this, "portrait", Toast.LENGTH_SHORT).show();

            {

                DocumentReference docRef = db.collection("games").document("MyDoc1");
                docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {
                                isGameStateFinished = Boolean.parseBoolean(document.get("finished").toString());


                                //if (isGameStateFinished == false) {
                                    try {

                                       //  Toast.makeText(GameActivity.this, "Game has not WON yet.Fetching its state NOW...", Toast.LENGTH_LONG).show();

                                        DocumentReference docRef = db.collection("games").document("MyDoc1");
                                        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                            @Override
                                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                                if (task.isSuccessful()) {
                                                    DocumentSnapshot document = task.getResult();
                                                    if (document.exists()) {

                                                        ArrayList<String> gotList = (ArrayList<String>) document.get("field");//take arraylist to gotlist

                                                       // Toast.makeText(GameActivity.this, "Yes I m in..."+(gotList == null), Toast.LENGTH_SHORT).show();
                                                        for(int i=0;i<99;i++)
                                                        {
                                                            if (gotList.get(i) != null) {
                                                                buttons[i/10][i%10].setText(gotList.get(i).toString());

                                                                Toast.makeText(GameActivity.this, "Position"+i+" is"+gotList.get(i), Toast.LENGTH_SHORT).show();

                                                            }
                                                            else
                                                            {
                                                               // buttons[i/10][i%10].setText("H");
                                                            }
                                                        }



                                                        Log.d(TAG, "DocumentSnapshot data: " + document.get("finished"));
                                                    } else {
                                                        Log.d(TAG, "No such document");
                                                    }
                                                } else {
                                                    Log.d(TAG, "get failed with ", task.getException());
                                                }
                                            }
                                        });
                                    }catch(Exception ex)
                                    {
                                        // Toast.makeText(GameActivity.this,"Exception reading"+ex.toString(),Toast.LENGTH_LONG).show();
                                    }
                               /* }
                                else if(isGameStateFinished==true)
                                {
                                    // Toast.makeText(GameActivity.this,"Game is not started yet or last winner is already declared",Toast.LENGTH_LONG).show();

                                    // *******


                                }*/


                            } else {
                                Log.d(TAG, "No such document");
                            }
                        } else {
                            Log.d(TAG, "get failed with ", task.getException());
                        }
                    }
                });
            }

        }
    }



    public void refresh()//refresh some fields into database
    {

            DocumentReference docRef = db.collection("games").document("MyDoc1");
            docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            you_clicked = Boolean.parseBoolean(document.get("you_clicked").toString());
                            player_1_count = Integer.parseInt(document.get("player_1_count").toString());
                            player_2_count = Integer.parseInt(document.get("player_2_count").toString());
                          //  is_game_reset = Boolean.parseBoolean(document.get("is_game_reset").toString());

                          /*  if(player_1_count>player_2_count)
                            {
                                player1Turn=false;
                            }
                            else if(player_2_count>player_1_count)
                            {
                                player1Turn = true;
                            }*/



                            if (you_clicked == true) {
                              //  Toast.makeText(GameActivity.this,"I got you_clicked="+you_clicked,Toast.LENGTH_LONG).show();

                                try {

                                    //  Toast.makeText(GameActivity.this, "Game has not WON yet.Fetching its state NOW...", Toast.LENGTH_LONG).show();

                                    DocumentReference docRef = db.collection("games").document("MyDoc1");
                                    docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                        @Override
                                        public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                            if (task.isSuccessful()) {
                                                DocumentSnapshot document = task.getResult();
                                                if (document.exists()) {

                                                    ArrayList<String> gotList = (ArrayList<String>) document.get("field");


                                                    for(int i=0;i<gotList.size();i++)
                                                    {
                                                        if (gotList.get(i) != null) {
                                                            buttons[i/10][i%10].setText(gotList.get(i).toString());

                                                        }
                                                    }



                                                    Log.d(TAG, "DocumentSnapshot data: " + document.get("you_clicked"));


                                                  /*  docRef
                                                            .update("you_clicked", false)
                                                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                @Override
                                                                public void onSuccess(Void aVoid) {
                                                                    Log.d(TAG, "DocumentSnapshot successfully UPDATED you_clicked FALSE!");
                                                                }
                                                            })
                                                            .addOnFailureListener(new OnFailureListener() {
                                                                @Override
                                                                public void onFailure(@NonNull Exception e) {
                                                                    Log.w(TAG, "Error updating document", e);
                                                                }
                                                            });*/
                                                } else {
                                                    Log.d(TAG, "No such document");
                                                }
                                            } else {
                                                Log.d(TAG, "get failed with ", task.getException());
                                            }
                                        }
                                    });
                                }catch(Exception ex)
                                {
                                    // Toast.makeText(GameActivity.this,"Exception reading"+ex.toString(),Toast.LENGTH_LONG).show();
                                }
                            }



                        } else {
                            Log.d(TAG, "No such document");
                        }
                    } else {
                        Log.d(TAG, "get failed with ", task.getException());
                    }
                }
            });


    }

    private boolean checkForWin() {
        String[][] field = new String[10][10];

        for (int i = 0; i < 10; i++) { // saving text in string array
            for (int j = 0; j < 10; j++) {
                field[i][j] = buttons[i][j].getText().toString();
            }
        }
        //  for the  first half of 5

        for (int i = 0; i < 10; i++) { //rows
            if (field[i][0].equals(field[i][1])
                    && field[i][0].equals(field[i][2])
                    && field[i][0].equals(field[i][3])
                    && field[i][0].equals(field[i][4])
                    && !field[i][0].equals("")) {
                return true;
            }
        }

        for (int i = 0; i < 10; i++) { //columns
            if (field[0][i].equals(field[1][i])
                    && field[0][i].equals(field[2][i])
                    && field[0][i].equals(field[3][i])
                    && field[0][i].equals(field[4][i])
                    && !field[0][i].equals("")) {
                return true;
            }
        }

        // second half of 5

        for (int i = 0; i < 10; i++) { //rows
            if (field[i][5].equals(field[i][6])
                    && field[i][5].equals(field[i][7])
                    && field[i][5].equals(field[i][8])
                    && field[i][5].equals(field[i][9])
                    && !field[i][5].equals("")) {
                return true;
            }
        }

        if (field[0][0].equals(field[1][1]) //diagonals 1
                && field[0][0].equals(field[2][2])
                && field[0][0].equals(field[3][3])
                && field[0][0].equals(field[4][4])
                && !field[0][0].equals("")) {
            return true;
        }

        if (field[0][2].equals(field[1][1]) //diagonals 2
                && field[0][2].equals(field[2][0])
                && !field[0][2].equals("")) {
            return true;
        }




        return false;
    }
    private void player1Wins() {
        //player1Points++;

        //player1Points = Integer.parseInt(player1points_from_network)+1;

        player1Points = Integer.parseInt(player1points_from_network)+1;//take already have points of player1 and add 1 to it

        player1points_from_network=String.valueOf(player1Points);
        Toast.makeText(this, "Player 1 wins!", Toast.LENGTH_SHORT).show();
        DocumentReference mygame1 = db.collection("games").document("MyDoc1");

// Set the "isCapital" field of the city 'DC'
        mygame1
                .update("finished", true)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully UPDATED FINISHED TRUE!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error updating document", e);
                    }
                });

        mygame1
                .update("winner_id", 1)//winner is player1

                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully updated ! WINNER ID SET TO 1");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error updating document", e);
                    }
                });

        blank_list = new ArrayList<>();
        for(int i=0;i<10;i++) {
            for (int j = 0; j < 10; j++) {
                blank_list.add("");
            }
        }
        mygame1
                .update("field", blank_list)//update all arraylist to blank now

                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully updated ! WINNER ID SET TO 1");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error updating document", e);
                    }
                });

        mygame1
                .update("player1Points", player1points_from_network)//player1 points update
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully UPDATED you_clicked FALSE!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error updating document", e);
                    }
                });
        mygame1
                .update("player2Points", player2points_from_network)//player 2 points update
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully UPDATED you_clicked FALSE!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error updating document", e);
                    }
                });

        mygame1
                .update("player_1_count", 0)

                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully updated ! WINNER ID SET TO 1");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error updating document", e);
                    }
                });

        mygame1
                .update("player_2_count", 0)

                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully updated ! WINNER ID SET TO 1");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error updating document", e);
                    }
                });



        updatePointsText();
        resetBoard();
    }

    private void player2Wins() {
       // player2Points++;

        player2Points = Integer.parseInt(player2points_from_network)+1;

        player2points_from_network=String.valueOf(player2Points);
        Toast.makeText(this, "Player 2 wins!", Toast.LENGTH_SHORT).show();

        DocumentReference mygame1 = db.collection("games").document("MyDoc1");

// Set the "isCapital" field of the city 'DC'
        mygame1
                .update("finished", true)

                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully updated!FINSISHED TRUE");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error updating document", e);
                    }
                });

        mygame1
                .update("winner_id", 2)

                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully updated!WINNER ID SET TO 2");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error updating document", e);
                    }
                });
        blank_list = new ArrayList<>();
        for(int i=0;i<10;i++) {
            for (int j = 0; j < 10; j++) {
                blank_list.add("");
            }
        }
        mygame1
                .update("field", blank_list)

                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully updated ! WINNER ID SET TO 1");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error updating document", e);
                    }
                });

        mygame1
                .update("player1Points", player1points_from_network)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully UPDATED you_clicked FALSE!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error updating document", e);
                    }
                });
        mygame1
                .update("player2Points", player2points_from_network)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully UPDATED you_clicked FALSE!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error updating document", e);
                    }
                });

        mygame1
                .update("player_1_count", 0)

                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully updated ! WINNER ID SET TO 1");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error updating document", e);
                    }
                });

        mygame1
                .update("player_2_count", 0)

                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully updated ! WINNER ID SET TO 1");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error updating document", e);
                    }
                });

        updatePointsText();
        resetBoard();
    }

    private void draw() {
        Toast.makeText(this, "Draw!", Toast.LENGTH_SHORT).show();
        resetBoard();
    }

    private void updatePointsText() {
        textViewPlayer1.setText("Player 1: " + player1points_from_network);
        textViewPlayer2.setText("Player 2: " + player2points_from_network);
    }

    private void resetBoard() {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                buttons[i][j].setText("");
            }

            DocumentReference docRef = db.collection("games").document("MyDoc1");

            docRef
                    .update("is_game_reset", true)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d(TAG, "DocumentSnapshot successfully UPDATED you_clicked FALSE!");
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.w(TAG, "Error updating document", e);
                        }
                    });

            docRef
                    .update("player1Points", 0)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d(TAG, "DocumentSnapshot successfully UPDATED you_clicked FALSE!");
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.w(TAG, "Error updating document", e);
                        }
                    });

            docRef
                    .update("player2Points", 0)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d(TAG, "DocumentSnapshot successfully UPDATED you_clicked FALSE!");
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.w(TAG, "Error updating document", e);
                        }
                    });

            blank_list = new ArrayList<>();
            for(int k=0;k<10;k++) {
                for (int l = 0; l < 10; l++) {
                    blank_list.add("");
                }
            }
            docRef
                    .update("field", blank_list)

                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d(TAG, "DocumentSnapshot successfully updated ! WINNER ID SET TO 1");
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.w(TAG, "Error updating document", e);
                        }
                    });
            docRef
                    .update("player_1_count", 0)

                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d(TAG, "DocumentSnapshot successfully updated ! WINNER ID SET TO 1");
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.w(TAG, "Error updating document", e);
                        }
                    });

            docRef
                    .update("player_2_count", 0)

                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d(TAG, "DocumentSnapshot successfully updated ! WINNER ID SET TO 1");
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.w(TAG, "Error updating document", e);
                        }
                    });

            docRef
                    .update("winner_id", 0)

                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d(TAG, "DocumentSnapshot successfully updated ! WINNER ID SET TO 1");
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.w(TAG, "Error updating document", e);
                        }
                    });

            docRef
                    .update("finished", true)

                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d(TAG, "DocumentSnapshot successfully updated ! WINNER ID SET TO 1");
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.w(TAG, "Error updating document", e);
                        }
                    });



        }

        DocumentReference mygame1 = db.collection("games").document("MyDoc1");
        blank_list = new ArrayList<>();
        for(int i=0;i<10;i++) {
            for (int j = 0; j < 10; j++) {
                blank_list.add("");
            }
        }
        mygame1
                .update("field", blank_list)

                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully updated ! WINNER ID SET TO 1");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error updating document", e);
                    }
                });

        roundCount = 0;
        player1Turn = true;

        finish();
        startActivity(getIntent());
    }

    private void resetGame() {
        player1Points = 0;
        player2Points = 0;
        updatePointsText();
        resetBoard();

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putInt("roundCount", roundCount);
        outState.putInt("player1Points", Integer.parseInt(player1points_from_network));
        outState.putInt("player2Points", Integer.parseInt(player2points_from_network));
        outState.putBoolean("player1Turn", player1Turn);
        outState.putStringArrayList("myList",myList);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        roundCount = savedInstanceState.getInt("roundCount");
        player1Points = savedInstanceState.getInt("player1Points");
        player2Points = savedInstanceState.getInt("player2Points");
        player1Turn = savedInstanceState.getBoolean("player1Turn");

      //  Toast.makeText(GameActivity.this,"RestoredInstance called",Toast.LENGTH_LONG).show();


    }

    @Override
    protected void onResume() {
        super.onResume();

 Toast.makeText(GameActivity.this,"I am in OnResume",Toast.LENGTH_LONG).show();
    }
}