import random
import sys

BOARD_SIZE = 8
HLINE = '  +' + '---+' * BOARD_SIZE
VLINE = '  |' + '   |' * BOARD_SIZE


def print_board(board):
    for y in range(BOARD_SIZE):
        print(VLINE)
        print(y + 1, end=' ')
        for x in range(BOARD_SIZE):
            print('| {}'.format(board[x][y]), end=' ')
        print('|')
        print(VLINE)
        print(HLINE)
    print('    ' + '   '.join(chr(ord('a') + i) for i in range(BOARD_SIZE)))


def reset_board(board):
    board[:] = [[' ' for y in range(BOARD_SIZE)] for x in range(BOARD_SIZE)]
    mid = BOARD_SIZE // 2
    board[mid - 1][mid - 1] = '2'
    board[mid][mid] = '2'
    board[mid - 1][mid] = '1'
    board[mid][mid - 1] = '1'


def get_new_board():
    board = [[' ' for y in range(BOARD_SIZE)] for x in range(BOARD_SIZE)]
    reset_board(board)
    return board


def is_on_board(x, y):
    # Returns True if the coordinates are located on the board.
    return 0 <= x < BOARD_SIZE and 0 <= y < BOARD_SIZE


def is_valid_move(board, player, move):
    if not is_on_board(*move) or board[move[0]][move[1]] != ' ':  # checks if the move is not on board or not empty
        return False

    # Check if move would flip any opponent pieces
    flips = []
    for xdir, ydir in [(0, 1), (1, 0), (0, -1), (-1, 0), (1, 1), (1, -1), (-1, 1), (-1, -1)]:  # getting the directions
        x, y = move
        x += xdir
        y += ydir
        while is_on_board(x, y) and board[x][y] == str(
                3 - player):  # while onboard and the piece is for the opponent then it continues to add to the
            # direction
            x += xdir
            y += ydir
        if is_on_board(x, y) and board[x][y] == str(player):
            # At least one opponent piece will be flipped by the move
            while True:  # when we run into the current plyaers piece then we start to backtrack the pieces
                x -= xdir
                y -= ydir
                if x == move[0] and y == move[1]:  # if t
                    break
                flips.append((x, y))  # then we they have been gotten we append them to the flips list

    if not flips:
        return False

    # Check if move would create a chain reaction of flips
    for fx, fy in flips:
        if is_valid_move(board, player, (fx, fy)):
            return True

    return True


def get_valid_moves(board, player):
    valid_moves = []
    for x in range(BOARD_SIZE):
        for y in range(BOARD_SIZE):
            if is_valid_move(board, player, (x, y)):
                valid_moves.append((x, y))
    return valid_moves


def switch_player(player):
    return 3 - player


def makeMove(board, player, move):
    if not is_valid_move(board, player, move):  # checks if the move is valid
        return None

    board[move[0]][move[1]] = str(player)  # setting the square corresponding to the move to the player's number

    for xdir, ydir in [(0, 1), (1, 0), (0, -1), (-1, 0), (1, 1), (1, -1), (-1, 1), (-1, -1)]:  # checking all the directions that can be flipped
        x, y = move
        x += xdir
        y += ydir
        flippedCells = []
        while is_on_board(x, y) and board[x][y] == str(3 - player):  #
            flippedCells.append((x, y))  # any opponents pieces found is added to the list as flipped
            x += xdir
            y += ydir
        if is_on_board(x, y) and board[x][y] == str(player):  # once the players piece is founf then then all the flipped pieces will changes to the players piece
            for x, y in flippedCells:
                board[x][y] = str(player)

    return board


def get_player_move(player):
    # Prompt the player to enter their move
    while True:
        try:
            move = input(f"Player {player}, enter your move (e.g. 'a1'): ")
            if len(move) != 2:
                raise ValueError()
            x = ord(move[0].lower()) - ord('a')
            y = int(move[1]) - 1
            if not is_on_board(x, y):
                raise ValueError()
            return (x, y)
        except ValueError:
            print("Invalid move, please try again.")


def play_game():
    print("Welcome to Othello!")
    board = get_new_board()
    print_board(board)
    current_player = 1

    while True:
        valid_moves = get_valid_moves(board, current_player)
        if not valid_moves:
            print(f"Player {current_player} has no valid moves!")
            current_player = switch_player(current_player)
            valid_moves = get_valid_moves(board, current_player)
            if not valid_moves:
                print("No more valid moves for either player!")
                break

        print(f"Player {current_player}'s turn.")
        print(f"Valid moves: {valid_moves}")
        move = get_player_move(current_player)
        board = makeMove(board, current_player, move)
        print_board(board)
        current_player = switch_player(current_player)

    print("Game over!")


if __name__ == '__main__':
    play_game()
