package com.example.tictactoe;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


import com.example.tictactoe.databinding.ActivityScoreBoard2Binding;
import com.google.firebase.database.annotations.Nullable;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.ArrayList;



public class ScoreBoard2 extends Activity {

    TextView txt_player1;
    TextView txt_player2;
    Button button_reset;

    String TAG = "mytag";

    String player1points_from_network="";
    String player2points_from_network="";

    FirebaseFirestore db;

//same as game actiivty.take snapshot and update points.On reset set to 0
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.score_board);

        db = FirebaseFirestore.getInstance();

        txt_player1 = findViewById(R.id.txt_player1);
        txt_player2 = findViewById(R.id.txt_player2);
        button_reset = findViewById(R.id.button_reset);

        DocumentReference mygame1 = db.collection("games").document("MyDoc1");
        button_reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mygame1
                        .update("player1Points", 0)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Log.d(TAG, "DocumentSnapshot successfully UPDATED you_clicked FALSE!");
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.w(TAG, "Error updating document", e);
                            }
                        });
                mygame1
                        .update("player2Points", 0)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Log.d(TAG, "DocumentSnapshot successfully UPDATED you_clicked FALSE!");
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.w(TAG, "Error updating document", e);
                            }
                        });
            }
        });


        final DocumentReference docRef1 = db.collection("games").document("MyDoc1");
        docRef1.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot snapshot,
                                @Nullable FirebaseFirestoreException e) {
                if (e != null) {
                    Log.w("Listen failed", "Listen failed.", e);
                    Toast.makeText(ScoreBoard2.this,"Listen failed."+snapshot.getData(),Toast.LENGTH_LONG).show();

                    return;
                }

                if (snapshot != null && snapshot.exists()) {
                    Log.d("Data", "Current data: " + snapshot.getData());
                    // Toast.makeText(GameActivity.this,"Current data:"+snapshot.getData(),Toast.LENGTH_LONG).show();




                    player1points_from_network = snapshot.get("player1Points").toString();
                    player2points_from_network = snapshot.get("player2Points").toString();

                    Toast.makeText(ScoreBoard2.this,"player1points_from_network = "+player1points_from_network+"player2points_points = "+player2points_from_network,Toast.LENGTH_LONG).show();

                    txt_player1.setText("Player 1 : "+player1points_from_network);
                    txt_player2.setText("Player 2 : "+player2points_from_network);




                } else {
                    Log.d("Data null", "Current data: null");
                }
            }
        });



    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        // Checks the orientation of the screen
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            Toast.makeText(this, "landscape", Toast.LENGTH_SHORT).show();
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT){
            Toast.makeText(this, "portrait", Toast.LENGTH_SHORT).show();
        }
    }


}