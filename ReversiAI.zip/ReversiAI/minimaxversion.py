import random
import sys

BOARD_SIZE = 8
HLINE = '  +' + '---+' * BOARD_SIZE
VLINE = '  |' + '   |' * BOARD_SIZE


def print_board(board):
    for y in range(BOARD_SIZE):
        print(VLINE)
        print(y + 1, end=' ')
        for x in range(BOARD_SIZE):
            print('| {}'.format(board[x][y]), end=' ')
        print('|')
        print(VLINE)
        print(HLINE)
    print('    ' + '   '.join(chr(ord('a') + i) for i in range(BOARD_SIZE)))


def reset_board(board):
    board[:] = [[' ' for y in range(BOARD_SIZE)] for x in range(BOARD_SIZE)]
    mid = BOARD_SIZE // 2
    board[mid - 1][mid - 1] = '2'
    board[mid][mid] = '2'
    board[mid - 1][mid] = '1'
    board[mid][mid - 1] = '1'


def get_new_board():
    board = [[' ' for y in range(BOARD_SIZE)] for x in range(BOARD_SIZE)]
    reset_board(board)
    return board


def is_on_board(x, y):
    # Returns True if the coordinates are located on the board.
    return 0 <= x < BOARD_SIZE and 0 <= y < BOARD_SIZE


def is_valid_move(board, player, move):
    if not is_on_board(*move) or board[move[0]][move[1]] != ' ':  # checks if the move is not on board or not empty
        return False

    # Check if move would flip any opponent pieces
    flips = []
    for xdir, ydir in [(0, 1), (1, 0), (0, -1), (-1, 0), (1, 1), (1, -1), (-1, 1), (-1, -1)]:  # getting the directions
        x, y = move
        x += xdir
        y += ydir
        while is_on_board(x, y) and board[x][y] == str(
                3 - player):  # while onboard and the piece is for the opponent then it continues to add to the
            # direction
            x += xdir
            y += ydir
        if is_on_board(x, y) and board[x][y] == str(player):
            # At least one opponent piece will be flipped by the move
            while True:  # when we run into the current plyaers piece then we start to backtrack the pieces
                x -= xdir
                y -= ydir
                if x == move[0] and y == move[1]:  # if t
                    break
                flips.append((x, y))  # then we they have been gotten we append them to the flips list

    if not flips:
        return False

    # Check if move would create a chain reaction of flips
    for fx, fy in flips:
        if is_valid_move(board, player, (fx, fy)):
            return True

    return True


def get_valid_moves(board, player):
    valid_moves = []
    for x in range(BOARD_SIZE):
        for y in range(BOARD_SIZE):
            if is_valid_move(board, player, (x, y)):
                valid_moves.append((x, y))
    return valid_moves


def switch_player(player):
    return 3 - player


def makeMove(board, player, move):
    # check if move is valid
    if not is_valid_move(board, player, move):
        print('Invalid move. Try again.')
        return board

    # update board
    new_board = [row[:] for row in board]  # create a copy of the board
    row, col = move
    new_board[row][col] = str(player)

    # flip opponent pieces
    flips = []
    for xdir, ydir in [(0, 1), (1, 0), (0, -1), (-1, 0), (1, 1), (1, -1), (-1, 1),
                       (-1, -1)]:  # checking all the directions that can be flipped
        x, y = move
        x += xdir
        y += ydir
        while is_on_board(x, y) and board[x][y] == str(3 - player):
            x += xdir
            y += ydir
        if is_on_board(x, y) and board[x][y] == str(
                player):  # once the players piece is founf  then all the flipped pieces will change to the players piece
            while True:
                x -= xdir
                y -= ydir
                if x == move[0] and y == move[1]:
                    break
                flips.append((x, y))  # any opponents pieces found is added to the list as flipped

    for fx, fy in flips:  # turning the opponents pieces fromthe list to the current players pieces
        new_board[fx][fy] = str(player)

    return new_board


def get_player_move(player):
    # Prompt the player to enter their move
    while True:
        try:
            move = input(f"Player {player}, enter your move (e.g. 'a1'): ")
            if len(move) != 2:
                raise ValueError()
            x = ord(move[0].lower()) - ord('a')
            y = int(move[1]) - 1
            if not is_on_board(x, y):
                raise ValueError()
            return (x, y)
        except ValueError:
            print("Invalid move, please try again.")


def get_ai_move(board, player):
    def score_move(move):
        return get_score(makeMove(board, player, move), player)

    def alphabeta(node, depth, alpha, beta, maximizingPlayer):
        valid_moves = get_valid_moves(node, player)

        if depth == 0 or len(valid_moves) == 0:  # checking for valid moves
            return (None, get_score(node, player)) #returning the score

        if maximizingPlayer:
            max_val = float('-inf')
            best_move = None

            for move in valid_moves:  # checking through the valid moves in make move
                child = makeMove(node, player, move)
                if child is None:
                    continue

                _, value = alphabeta(child, depth - 1, alpha, beta, False)  # calling the function to evaluate the move

                if value > max_val:  # comparing current value to the max value so we get the best move
                    max_val = value
                    best_move = move

                alpha = max(alpha, max_val)  # setting alpha to the greatest value and comparing it to beta
                if alpha >= beta:  # to decide if to prune or not
                    break

            return (best_move, max_val)
        else:
            min_val = float('inf')
            best_move = None

            for move in valid_moves:
                child = makeMove(node, switch_player(player), move)
                if child is None:
                    continue

                _, value = alphabeta(child, depth - 1, alpha, beta, True)

                if value < min_val:
                    min_val = value
                    best_move = move

                beta = min(beta, min_val)
                if beta <= alpha:
                    break

            return (best_move, min_val)

    def get_score(board, player):
        score = 0

        for x in range(BOARD_SIZE):
            for y in range(BOARD_SIZE):
                if board[x][y] == str(player):
                    score += 1
                elif board[x][y] == str(switch_player(player)):
                    score -= 1

        return score

    depth = 4
    move, _ = alphabeta(board, depth, float('-inf'), float('inf'), True)
    return move


def play_game():
    print("Welcome to Othello!")
    board = get_new_board()
    print_board(board)
    current_player = 1

    while True:
        valid_moves = get_valid_moves(board, current_player)
        if not valid_moves:
            print(f"Player {current_player} has no valid moves!")
            current_player = switch_player(current_player)
            valid_moves = get_valid_moves(board, current_player)
            if not valid_moves:
                print("No more valid moves for either player!")
                break

        if current_player == 1:
            print(f"Player {current_player}'s turn.")
            print(f"Valid moves: {valid_moves}")
            move = get_player_move(current_player)
        else:
            print(f"AI's turn.")
            move = get_ai_move(board, current_player)

        board = makeMove(board, current_player, move)
        print_board(board)
        current_player = switch_player(current_player)

    print("Game over!")


if __name__ == '__main__':
    play_game()
